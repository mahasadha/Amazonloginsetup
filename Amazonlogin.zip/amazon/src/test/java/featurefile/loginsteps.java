package featurefile;
import io.cucumber.java.en.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import java.util.concurrent.TimeUnit;

public class loginsteps {
    WebDriver driver;

    @Given("I am on the Login page URL {string}")
    public void i_am_on_the_login_page_url(String url) {
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\vignesh\\Downloads\\chromedriver-win64\\chromedriver-win64\\chromedriver.exe\\");
        driver = new ChromeDriver();
        driver.get(url);
    }

    @Then("I click on sign in button and wait for sign in page")
    public void i_click_on_sign_in_button_and_wait_for_sign_in_page() {
        WebElement signInButton = driver.findElement(By.xpath("//span[@id='nav-link-accountList-nav-line-1']"));
        signInButton.click();
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
    }

  

    @When("I enter username as {string}")
    public void i_enter_username_as(String username) {
        WebElement usernameField = driver.findElement(By.xpath("//input[@id='ap_email']"));
        usernameField.sendKeys("mahasadha201@gmail.com");
    }

    @And("I Click on Continue button")
    public void i_click_on_continue_button() {
        WebElement continueButton = driver.findElement(By.xpath("//input[@id='continue']"));
        continueButton.click();
    }
    
    @And("I enter password as {string}")
    public void i_enter_password_as(String password) {
        WebElement passwordField = driver.findElement(By.xpath("//input[@id='ap_password']"));
        passwordField.sendKeys("ssvm@4036");
    }
    
    @And("click on login button")
    public void click_on_login_button() {
        WebElement loginButton = driver.findElement(By.xpath("//input[@id='signInSubmit']"));
        loginButton.click();
    }

    @Then("I am logged in")
    public void i_am_logged_in() {
        WebElement userAccount = driver.findElement(By.id("glow-ingress-line2"));
        assert(userAccount.isDisplayed());
    }

    @And("I clear cart items if any")
    public void i_clear_cart_items_if_any() {
    	WebElement CartButton = driver.findElement(By.xpath("//span[@id='nav-cart-count']"));
    	CartButton.click();
    	
    	WebElement ClearButton = driver.findElement(By.xpath("//input[@name='submit.delete.ff3f07b1-a8c0-400b-a9fb-afd258a175ef']"));
    	ClearButton.click();
    	
    }

    @Then("I choose Electronics > Headphones and headphones list out")
    public void i_choose_electronics_headphones_and_headphones_list_out() {
    	WebElement AllButton = driver.findElement(By.xpath("//i[@class='hm-icon nav-sprite']"));
    	AllButton.click();
    	
    	WebElement EleButton = driver.findElement(By.xpath("//div[normalize-space()='TV, Appliances, Electronics']"));
    	EleButton.click();
    	
    	WebElement HeadButton = driver.findElement(By.xpath("//a[normalize-space()='Headphones']"));
    	HeadButton.click();
    	
    }

    @Then("I add first available headphone to cart")
    public void i_add_first_available_headphone_to_cart() {
    	WebElement ImgButton = driver.findElement(By.xpath("//div[@class='apb-default-slot apb-default-merchandised-search-10']//div[2]//div[1]//div[1]//div[1]//a[1]//img[1]"));
    	ImgButton.click();
    	
    	WebElement FirstButton = driver.findElement(By.xpath("//input[@id='add-to-cart-button']"));
    	FirstButton.click();
        // Code to add first available headphone to cart
    }

    @Then("I search macbook pro and add second available item to cart")
    public void i_search_and_add_second_available_item_to_cart(String item) {
    	
    	WebElement SearchButton = driver.findElement(By.xpath("//input[@id='twotabsearchtextbox']"));
    	SearchButton.sendKeys("macbook pro");
    	
    	WebElement OkButton = driver.findElement(By.xpath("//input[@id='nav-search-submit-button']"));
    	OkButton.click();
    	
    	WebElement SelectButton = driver.findElement(By.xpath("//button[@id='a-autoid-2-announce']"));
    	SelectButton.click();

    }

    @Then("I Select cart from home and remove the earlier added headphones")
    public void i_select_cart_from_home_and_remove_the_earlier_added_headphones() {
    	WebElement HomeButton = driver.findElement(By.xpath("//span[@class='nav-cart-icon nav-sprite']"));
    	HomeButton.click();
    	
    	WebElement DeleteHeadButton = driver.findElement(By.xpath("//input[@name='submit.delete.aaa40ea2-9aba-4201-9719-4517e5249099']"));
    	DeleteHeadButton.click();
 
    }

    @Then("I Reduce the Quantity of the macbook pro product to one and proceed to checkout")
    public void i_reduce_the_quantity_of_the_macbook_pro_product_to_one_and_proceed_to_checkout() {
    	
    	WebElement SendButton = driver.findElement(By.xpath("//input[@name='proceedToRetailCheckout']"));
    	SendButton.click();

    }

    @And("I Click on Sign out")
    public void i_click_on_sign_out() {
    	
    	WebElement SelectButton = driver.findElement(By.xpath("//button[@id='a-autoid-2-announce']"));
    	SelectButton.click();
    }

    @Then("I got log out from the application and land on sign in page")
    public void i_got_log_out_from_the_application_and_land_on_sign_in_page() {
    	
    	WebElement SignButton = driver.findElement(By.xpath("//span[normalize-space()='Account & Lists']"));
    	SignButton.click();	

    	WebElement SignOutButton = driver.findElement(By.xpath("//span[normalize-space()='Sign Out']"));
    	SignOutButton.click();
     
    }
   
}
    
    


















































//@Then("I should see Sign In Page")
//public void i_should_see_sign_in_page() {
  //  WebElement signInPage = driver.findElement(By.id("signInPage"));
   // assert(signInPage.isDisplayed());
//}
   